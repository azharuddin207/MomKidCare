
// const baseURL1 = `http://f7f099d1.ngrok.io/api/`;
const baseURL = `http://107e3c74.ngrok.io/api/`;
// const imgsrc = "http://107e3c74.ngrok.io";
export default baseURL;
