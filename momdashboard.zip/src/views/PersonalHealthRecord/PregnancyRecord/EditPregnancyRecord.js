import React from 'react';

class  EditPregnancyRecord extends React.Component {




  render() {
    return(
    <div>
      edit record
    </div>
    );
  }


}


export  default  EditPregnancyRecord
