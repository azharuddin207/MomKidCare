import React from "react";
import ViewmomDiary from "./ViewmomDiary";
// import {getMomDiaries, getOneMomDiary} from "../../../services/apiService";
// import AddmomDiary from "./AddmomDiary";

class MomDiary extends React.Component {


  render() {
    return (
      <div>
        <ViewmomDiary />
      </div>
    );
  }
}

export default MomDiary;
