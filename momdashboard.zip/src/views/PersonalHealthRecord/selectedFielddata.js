// import React from 'react';
//documentType for current pregancy
export const week0_6 = [
  "Prescription",
  "Urine Dip test",
 "Investigation Report",
 "Ultrasonography",
 "Any other Report"
]
export const week7_15=[
 "Prescription",
 "1st Screening report (HCG, PAPPCA, Quadruple, triple, double marker test)",
 "Investigation Report",
 "Ultrasonography",
 "Any other Report"
]

export const week16_27=[
 "Prescription",
  "2nd Screening reports (if any) (Chronic V.S, Chordocenter, Fetal DNA, Fetal echography etc.)",
 "Investigation Report",
   "Ultrasonography",
 "Any other Report"
]

export const week28_32=[
   "Prescription",
   "Discharge summary",
   "Procedure/Surgery if any",
   "Investigation Report",
   "Ultrasonography",
   "Genetic testing Report",
   "Any other Report"
]


//document Tyep pre-oregnancy

export const pre_pregnancyData = [
      "Prescription",
      "Blood report",
      "Hormone report",
      "Follicle Report",
      "USG",
      "HSG",
      "Semen analysis",
      "Laparoscopy/Hysteroscopy",
      "IUI cycles",
      "IVF cycles",
      "Any surgical procedure"
] 


export const post_pregnancyData = [
  "Prescription",
  "Discharge summary",
  "Procedure/Surgery if any",
  "Routine Investigation",
  "Ultrasonography",
  "Any other Report"
]